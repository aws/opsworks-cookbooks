<?php

/* Pass in by reference! */
function graph_passenger_status_report ( &$rrdtool_graph ) {

    global $context,
           $conf,
           $hostname,
           $range,
           $rrd_dir,
           $size,
           $strip_domainname;

    if ($strip_domainname) {
       $hostname = strip_domainname($hostname);
    }

    $rrdtool_graph['height'] += ($size == 'medium') ? 76 : 0;
    $title = 'Passenger Processes';
    if ($context != 'host') {
       $rrdtool_graph['title'] = $title;
    } else {
       $rrdtool_graph['title'] = "$hostname $title last $range";
    }
    $rrdtool_graph['lower-limit']    = '0';
    $rrdtool_graph['vertical-label'] = 'Processes';
    $rrdtool_graph['extras']         = '--rigid';


    if ( file_exists("$rrd_dir/passenger_avg_memory.rrd")) {

      $series = "DEF:'passenger_max_processes'='${rrd_dir}/passenger_max_processes.rrd':'sum':AVERAGE "
              . "DEF:'passenger_current_processes'='${rrd_dir}/passenger_current_processes.rrd':'sum':AVERAGE "
              . "DEF:'passenger_active_processes'='${rrd_dir}/passenger_active_processes.rrd':'sum':AVERAGE "
              . "DEF:'passenger_inactive_processes'='${rrd_dir}/passenger_inactive_processes.rrd':'sum':AVERAGE "
              . "DEF:'passenger_waiting_processes'='${rrd_dir}/passenger_waiting_processes.rrd':'sum':AVERAGE "
              . "DEF:'passenger_sessions'='${rrd_dir}/passenger_sessions.rrd':'sum':AVERAGE "

              . "LINE2:'passenger_max_processes'#${conf['cpu_num_color']}:'Max Passenger Processes' "
              . "LINE2:'passenger_current_processes'#${conf['proc_run_color']}:'Current' "
              . "LINE2:'passenger_active_processes'#33FF11:'Active' "
              . "LINE2:'passenger_inactive_processes'#${conf['load_one_color']}:'Inactive' "
              . "LINE2:'passenger_waiting_processes'#FF7700:'Waiting' "
              . "LINE2:'passenger_sessions'#FF00FF:'Sessions' ";
      
    } else {
       # If there are no Passenger metrics put something so that the report doesn't barf
       $series  = "DEF:'cpu_num'='${rrd_dir}/cpu_num.rrd':'sum':AVERAGE "
                . "LINE2:'cpu_num'#${conf['mem_swapped_color']}:'Passenger metrics not collected' ";
    }

    $rrdtool_graph['series'] = $series;

    return $rrdtool_graph;

}

?>
